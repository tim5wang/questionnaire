-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: phalapi
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_answer`
--

DROP TABLE IF EXISTS `tbl_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identify` varchar(1024) NOT NULL,
  `job` char(32) NOT NULL,
  `ip` char(64) NOT NULL,
  `answer` text NOT NULL,
  `begin_time` timestamp NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_answer`
--

LOCK TABLES `tbl_answer` WRITE;
/*!40000 ALTER TABLE `tbl_answer` DISABLE KEYS */;
INSERT INTO `tbl_answer` VALUES (1,'\"女\"','job2','223.104.63.192','[\"女\",\"女\",\"女\",\"女\",\"女\",[\"东部华侨城\"],[\"大梅沙\",\"欢乐谷\"],[\"12121\",\"双方家里\",\"3\"],[\"1212\",\"双方家里\",\"2\"],\"111111\",\"1111111111111\"]','2019-02-18 04:57:16','2019-02-18 04:57:46','2019-02-18 04:57:46',2),(5,'[\"\"]','job3','223.104.63.192','[[\"\"]]','2019-02-18 05:16:51','2019-02-18 05:16:53','2019-02-18 05:16:53',3);
/*!40000 ALTER TABLE `tbl_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_group`
--

DROP TABLE IF EXISTS `tbl_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_group` (
  `id` int(11) NOT NULL,
  `title` char(64) NOT NULL,
  `rules` varchar(1024) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mrules` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_group`
--

LOCK TABLES `tbl_group` WRITE;
/*!40000 ALTER TABLE `tbl_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_model`
--

DROP TABLE IF EXISTS `tbl_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `job` char(32) NOT NULL,
  `desc` varchar(1024) NOT NULL,
  `identify` char(11) NOT NULL DEFAULT 'false',
  `title` varchar(1024) NOT NULL,
  `time_limit` char(11) NOT NULL DEFAULT 'false',
  `status` char(32) NOT NULL,
  `questions` text NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job` (`job`),
  KEY `user_id` (`user_id`) USING BTREE,
  FULLTEXT KEY `desc` (`desc`),
  FULLTEXT KEY `title` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_model`
--

LOCK TABLES `tbl_model` WRITE;
/*!40000 ALTER TABLE `tbl_model` DISABLE KEYS */;
INSERT INTO `tbl_model` VALUES (2,1,'job2','这个是一个问卷模板，包含四种问题类型，位于questions中，您可以在此基础上实现你的问卷,\n            其中job是这个问卷的文艺标志，title是问卷的标题，desc为问卷的说明，\n            time_limit如果答题限时设置为正整数秒，设置为false时不限制时间，identify题目数组的下标，\n            标志出能唯一区分用户的问题，如名字/电话;weight代表分数;standard_answer代表标准答案;','3','联谊活动报名及基本信息采集，为了这次联谊起到更好的效果，请认真填写本问卷，谢谢配合！','3600','已发布','[{\"type\":\"single_chose\",\"question\":\"性别\",\"require\":true,\"options\":{\"男\":\"绅士\",\"女\":\"女士\"},\"weight\":1,\"standard_answer\":\"\"},{\"type\":\"single_chose\",\"question\":\"性别\",\"require\":true,\"options\":{\"男\":\"绅士\",\"女\":\"女士\"},\"weight\":1,\"standard_answer\":\"\"},{\"type\":\"single_chose\",\"question\":\"性别\",\"require\":true,\"options\":{\"男\":\"绅士\",\"女\":\"女士\"},\"weight\":1,\"standard_answer\":\"\"},{\"type\":\"single_chose\",\"question\":\"性别\",\"require\":true,\"options\":{\"男\":\"绅士\",\"女\":\"女士\"},\"weight\":1,\"standard_answer\":\"\"},{\"type\":\"single_chose\",\"question\":\"性别\",\"require\":true,\"options\":{\"男\":\"绅士\",\"女\":\"女士\"},\"weight\":1,\"standard_answer\":\"\"},{\"type\":\"multi_chose\",\"max_chosen\":3,\"min_chosen\":1,\"require\":true,\"question\":\"想去哪个景点晚？\",\"options\":{\"世界之窗\":\"世界之窗，门票约200元，耗时约半天。\",\"东部华侨城\":\"华侨城，门票约200元，耗时约1天\",\"欢乐谷\":\"欢乐谷，门票约200元，耗时约1天\",\"锦绣中华\":\"锦绣中华，位于世界之窗隔壁，门票约200元，耗时约半天\",\"大梅沙\":\"大梅沙海滩，免费，请带好泳具，耗时约半天\"},\"weight\":1,\"standard_answer\":[]},{\"type\":\"multi_chose\",\"max_chosen\":3,\"min_chosen\":1,\"require\":true,\"question\":\"想去哪个景点晚？\",\"options\":{\"世界之窗\":\"世界之窗，门票约200元，耗时约半天。\",\"东部华侨城\":\"华侨城，门票约200元，耗时约1天\",\"欢乐谷\":\"欢乐谷，门票约200元，耗时约1天\",\"锦绣中华\":\"锦绣中华，位于世界之窗隔壁，门票约200元，耗时约半天\",\"大梅沙\":\"大梅沙海滩，免费，请带好泳具，耗时约半天\"},\"weight\":1,\"standard_answer\":[]},{\"type\":\"fill\",\"require\":false,\"condition\":[{\"question\":0,\"answer\":\"女\",\"join\":\"or\"}],\"question\":\"我可以接受$relation$（好朋友\\/伴侣\\/性伴侣\\/炮友）关系，我愿意在$location$（地方）放纵，我愿意一周放纵$times$（数字）次。\",\"map\":{\"relation\":{\"type\":\"text\"},\"location\":{\"type\":\"select\",\"options\":[\"没人看到的公共场所\",\"双方家里\",\"宾馆\",\"小树林\"]},\"times\":{\"type\":\"number\"}},\"weight\":1,\"standard_answer\":[]},{\"type\":\"fill\",\"require\":false,\"condition\":[{\"question\":0,\"answer\":\"女\",\"join\":\"or\"}],\"question\":\"我可以接受$relation$（好朋友\\/伴侣\\/性伴侣\\/炮友）关系，我愿意在$location$（地方）放纵，我愿意一周放纵$times$（数字）次。\",\"map\":{\"relation\":{\"type\":\"text\"},\"location\":{\"type\":\"select\",\"options\":[\"没人看到的公共场所\",\"双方家里\",\"宾馆\",\"小树林\"]},\"times\":{\"type\":\"number\"}},\"weight\":1,\"standard_answer\":[]},{\"type\":\"answer\",\"require\":true,\"question\":\"你最自卑的一件事情是什么？(将为您保护隐私)\",\"weight\":1,\"standard_answer\":\"\"},{\"type\":\"answer\",\"require\":true,\"question\":\"你最自卑的一件事情是什么？(将为您保护隐私)\",\"weight\":1,\"standard_answer\":\"\"}]','2019-02-17 14:36:58','2019-02-17 15:52:37'),(3,1,'job3','demo','0','wenjuan','3600','已发布','[{\"type\":\"answer\",\"require\":true,\"question\":\"你最自卑的一件事情是什么？(将为您保护隐私)\",\"weight\":1,\"standard_answer\":\"\"}]','2019-02-17 15:18:31','2019-02-18 05:05:02');
/*!40000 ALTER TABLE `tbl_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rule`
--

DROP TABLE IF EXISTS `tbl_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` char(64) NOT NULL,
  `title` char(64) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `authopen` tinyint(1) NOT NULL,
  `pid` int(11) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rule`
--

LOCK TABLES `tbl_rule` WRITE;
/*!40000 ALTER TABLE `tbl_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` char(64) NOT NULL,
  `password` char(64) NOT NULL,
  `id_group` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` char(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES (1,'tim5wang','123123',0,1,'2019-02-16 09:56:43','2019-02-16 09:56:43','超级管理员');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-23 15:42:02
